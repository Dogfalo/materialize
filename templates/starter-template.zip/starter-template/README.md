![alt tag](https://raw.github.com/dogfalo/materialize/master/images/materialize.gif)
===========
Materialize, a CSS Framework based on material design

### Current Version : v0.92.0

##Changelog

- v0.92.0
  - Clicking icon in dropdown in navbar no longer closes dropdown immediately
  - Multiple select inputs now work properly
  - Mobile navbar no longer extends past screen width
  - Parallax improved
  - Modal restructured / can be opened programmatically
  - Callbacks added to modals
  - Added dist folder to repo


- v0.91
  - bug fixes to forms
  - added waves color classes
  - toast thickened to look better on mobile
  - many other bug fixes


- v0.9
  - Touch interactions added
  - tons more...
